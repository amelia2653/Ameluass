package com.example.Ameluass

data class LinkModel(
    val title: String,
    val image: Int,
    val url: String,
)
